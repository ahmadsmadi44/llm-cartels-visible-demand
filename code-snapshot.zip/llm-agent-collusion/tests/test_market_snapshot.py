"""[sprint addition] Regression test for the same-round order-book leak (upstream issue #4)."""
import threading
import time

from src.continuous_double_auction.cda_types import Agent, ExperimentParams
from src.continuous_double_auction.market.market import Market

PARAMS = ExperimentParams(seller_valuations=[80.0, 80.0], buyer_valuations=[100.0],
                          seller_models=["x", "x"], buyer_models=["zip"], rounds=2)
seen = {}


class Fast(Agent):
    def generate_bid_response(self, **kw):
        return {"ask": 91.0}


class Slow(Agent):
    def generate_bid_response(self, **kw):
        time.sleep(0.3)  # answers after Fast has already written its ask
        seen["ask_queue"] = list(kw["ask_queue"])
        return {"ask": 95.0}


class Buyer(Agent):
    def generate_bid_response(self, **kw):
        return {"bid": 50.0}


def test_no_same_round_leak():
    sellers = [Fast(id="Seller A", company="a", valuation=80, expt_params=PARAMS),
               Slow(id="Seller B", company="b", valuation=80, expt_params=PARAMS)]
    buyers = [Buyer(id="Buyer C", company="c", valuation=100, expt_params=PARAMS)]
    m = Market(sellers=sellers, buyers=buyers)
    m.run_round()
    # Slow must not see Fast's $91 ask placed in the same round
    assert all(price != 91.0 for price, _ in seen["ask_queue"]), seen["ask_queue"]
